ChartIQ Study Calculator Module

See https://documentation.chartiq.com/StudyCalculator.html for all details.